import { useState } from 'react'
import './App.css'




function App() {
  const [color, setColor] = useState("olive");

  return (
   
     <div style={{backgroundColor:color}}>OnClick Background Color change

       <div className= "fixed flex flex-wrap justify-center bottom-12 inset-x-0 px-2"> <button onClick={() =>setColor('red')}>RED</button> </div>
       <div className= "fixed flex flex-wrap justify-center bottom-12 inset-x-0 px-2"> <button onClick={()=>setColor('green')}>Green</button> </div>
       <div className= "fixed flex flex-wrap justify-center bottom-12 inset-x-0 px-2"> <button onClick={()=>setColor('blue')}>Blue</button> </div>
       <div className= "fixed flex flex-wrap justify-center bottom-12 inset-x-0 px-2"> <button onClick={()=>setColor('yellow')}>Yellow</button> </div>

     </div>


      
  )
}

export default App
