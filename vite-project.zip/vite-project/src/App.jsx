import { useState } from 'react'

function App() {
  const [counter, setCounter] = useState(0) //initilaze is required for useState function


 function addValue() {
    if (counter < 20) {
      setCounter(counter + 1);
      console.log(counter);  
    }
  }

  //Arrow function define //

  const removeValue = () => {
    if(counter >0){
      setCounter(counter - 1);
    }
  }
  return (
    <>
    <span>Show counter value:  {counter}</span> 
    <button onClick={addValue}>Add value {counter}</button>
    <button onClick={removeValue}>Remove value</button>
    </>
  )
}

export default App
